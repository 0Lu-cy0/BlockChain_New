import React, { useState, useEffect } from 'react';
import { traceabilityAPI } from '../services/api';
import { toast } from 'react-toastify';

const Traceability = () => {
  const [traceabilityData, setTraceabilityData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedVineyard, setSelectedVineyard] = useState(null);
  const [showModal, setShowModal] = useState(false);

  useEffect(() => {
    fetchTraceabilityData();
  }, []);

  const fetchTraceabilityData = async () => {
    try {
      setLoading(true);
      const response = await traceabilityAPI.getAll();
      setTraceabilityData(response.data.data);
    } catch (error) {
      toast.error('Lỗi khi tải dữ liệu truy xuất');
    } finally {
      setLoading(false);
    }
  };

  const viewDetails = (vineyard) => {
    setSelectedVineyard(vineyard);
    setShowModal(true);
  };

  const getFileIcon = (fileType) => {
    if (fileType.includes('image')) return '🖼️';
    if (fileType.includes('pdf')) return '📄';
    if (fileType.includes('video')) return '🎥';
    return '📎';
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleString('vi-VN');
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-wine-800 mb-6">Truy xuất nguồn gốc rượu vang</h1>

      {loading ? (
        <div className="text-center py-12">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-wine-600"></div>
          <p className="mt-4 text-gray-600">Đang tải dữ liệu...</p>
        </div>
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {traceabilityData.map((vineyard) => (
            <div
              key={vineyard.id}
              className="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition"
            >
              <div className="bg-gradient-to-r from-wine-600 to-wine-700 text-white p-4">
                <h3 className="text-xl font-bold">{vineyard.name}</h3>
                <p className="text-wine-100 text-sm">{vineyard.grape_variety}</p>
              </div>
              
              <div className="p-4">
                <div className="space-y-2 mb-4">
                  <p className="text-sm">
                    <strong className="text-gray-700">Chủ sở hữu:</strong>{' '}
                    <span className="text-gray-600">{vineyard.owner}</span>
                  </p>
                  <p className="text-sm">
                    <strong className="text-gray-700">Tọa độ:</strong>{' '}
                    <span className="text-gray-600">{vineyard.latitude}, {vineyard.longitude}</span>
                  </p>
                  <p className="text-sm">
                    <strong className="text-gray-700">Số quy trình:</strong>{' '}
                    <span className="text-wine-600 font-semibold">
                      {vineyard.processes ? vineyard.processes.length : 0}
                    </span>
                  </p>
                </div>

                <button
                  onClick={() => viewDetails(vineyard)}
                  className="w-full bg-wine-600 text-white py-2 rounded-lg hover:bg-wine-700 transition font-semibold"
                >
                  🔍 Xem chi tiết
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {traceabilityData.length === 0 && !loading && (
        <div className="text-center py-12 bg-white rounded-lg shadow">
          <p className="text-gray-500 text-lg">Chưa có dữ liệu truy xuất nào.</p>
        </div>
      )}

      {/* Detail Modal */}
      {showModal && selectedVineyard && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4 overflow-y-auto">
          <div className="bg-white rounded-lg max-w-4xl w-full my-8">
            <div className="bg-gradient-to-r from-wine-600 to-wine-700 text-white p-6 rounded-t-lg">
              <div className="flex justify-between items-start">
                <div>
                  <h2 className="text-2xl font-bold mb-2">{selectedVineyard.name}</h2>
                  <p className="text-wine-100">{selectedVineyard.grape_variety}</p>
                </div>
                <button
                  onClick={() => setShowModal(false)}
                  className="text-white hover:text-wine-200 text-3xl leading-none"
                >
                  ×
                </button>
              </div>
            </div>

            <div className="p-6">
              {/* Vineyard Information */}
              <div className="mb-6">
                <h3 className="text-xl font-bold text-wine-800 mb-3">📍 Thông tin vườn nho</h3>
                <div className="bg-gray-50 rounded-lg p-4 space-y-2">
                  <p>
                    <strong className="text-gray-700">Chủ sở hữu:</strong>{' '}
                    {selectedVineyard.owner}
                  </p>
                  <p>
                    <strong className="text-gray-700">Giống nho:</strong>{' '}
                    {selectedVineyard.grape_variety}
                  </p>
                  <p>
                    <strong className="text-gray-700">Tọa độ:</strong>{' '}
                    {selectedVineyard.latitude}, {selectedVineyard.longitude}
                    <a
                      href={`https://www.google.com/maps?q=${selectedVineyard.latitude},${selectedVineyard.longitude}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="ml-2 text-wine-600 hover:underline"
                    >
                      (Xem bản đồ)
                    </a>
                  </p>
                  <p>
                    <strong className="text-gray-700">Ngày tạo:</strong>{' '}
                    {formatDate(selectedVineyard.created_at)}
                  </p>
                </div>
              </div>

              {/* Fermentation Processes */}
              <div>
                <h3 className="text-xl font-bold text-wine-800 mb-3">
                  🍷 Quy trình ủ rượu ({selectedVineyard.processes?.length || 0})
                </h3>
                
                {selectedVineyard.processes && selectedVineyard.processes.length > 0 ? (
                  <div className="space-y-4">
                    {selectedVineyard.processes.map((process) => (
                      <div
                        key={process.id}
                        className="border border-gray-200 rounded-lg p-4 hover:border-wine-300 transition"
                      >
                        <div className="flex items-start justify-between mb-2">
                          <h4 className="font-bold text-lg text-gray-800 flex items-center">
                            {getFileIcon(process.file_type)} {process.title}
                          </h4>
                          <span className="text-xs bg-wine-100 text-wine-800 px-2 py-1 rounded">
                            {process.file_type}
                          </span>
                        </div>
                        
                        {process.description && (
                          <p className="text-gray-600 mb-3">{process.description}</p>
                        )}

                        <div className="bg-blue-50 rounded p-3 mb-3">
                          <p className="text-sm mb-1">
                            <strong className="text-gray-700">File:</strong>{' '}
                            {process.file_name}
                          </p>
                          <p className="text-sm mb-1">
                            <strong className="text-gray-700">IPFS CID:</strong>{' '}
                            <code className="bg-white px-2 py-1 rounded text-xs">
                              {process.ipfs_cid}
                            </code>
                          </p>
                          <p className="text-sm">
                            <strong className="text-gray-700">Ngày upload:</strong>{' '}
                            {formatDate(process.created_at)}
                          </p>
                        </div>

                        <a
                          href={`http://localhost:8080/ipfs/${process.ipfs_cid}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="block w-full bg-wine-600 text-white text-center py-2 rounded-lg hover:bg-wine-700 transition text-sm font-semibold"
                        >
                          🌐 Xem file trên IPFS
                        </a>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 bg-gray-50 rounded-lg">
                    <p className="text-gray-500">Chưa có quy trình ủ rượu nào được upload.</p>
                  </div>
                )}
              </div>
            </div>

            <div className="p-6 bg-gray-50 rounded-b-lg">
              <button
                onClick={() => setShowModal(false)}
                className="w-full bg-gray-300 text-gray-700 py-2 rounded-lg hover:bg-gray-400 transition font-semibold"
              >
                Đóng
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Traceability;

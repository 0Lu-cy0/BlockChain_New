import React, { useState, useEffect } from 'react';
import { vineyardAPI, processAPI } from '../services/api';
import { toast } from 'react-toastify';

const Upload = () => {
  const [vineyards, setVineyards] = useState([]);
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [formData, setFormData] = useState({
    vineyard_id: '',
    title: '',
    description: '',
    file: null
  });
  const [fileName, setFileName] = useState('');

  useEffect(() => {
    fetchVineyards();
  }, []);

  const fetchVineyards = async () => {
    try {
      setLoading(true);
      const response = await vineyardAPI.getAll();
      setVineyards(response.data.data);
    } catch (error) {
      toast.error('Lỗi khi tải danh sách vườn nho');
    } finally {
      setLoading(false);
    }
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setFormData({ ...formData, file });
      setFileName(file.name);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.file) {
      toast.error('Vui lòng chọn file để upload');
      return;
    }

    try {
      setUploading(true);
      const uploadData = new FormData();
      uploadData.append('file', formData.file);
      uploadData.append('vineyard_id', formData.vineyard_id);
      uploadData.append('title', formData.title);
      uploadData.append('description', formData.description);

      const response = await processAPI.upload(uploadData);
      
      toast.success('Upload quy trình thành công!');
      
      // Show IPFS info
      if (response.data.data.ipfs_cid) {
        toast.info(`IPFS CID: ${response.data.data.ipfs_cid}`, { autoClose: 5000 });
      }

      // Reset form
      setFormData({
        vineyard_id: '',
        title: '',
        description: '',
        file: null
      });
      setFileName('');
      e.target.reset();
    } catch (error) {
      toast.error(error.response?.data?.message || 'Lỗi khi upload file');
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-2xl mx-auto">
        <h1 className="text-3xl font-bold text-wine-800 mb-6">Upload quy trình ủ rượu</h1>
        
        <div className="bg-white rounded-lg shadow-lg p-8">
          <div className="mb-6 bg-wine-50 border-l-4 border-wine-600 p-4">
            <p className="text-sm text-wine-800">
              <strong>📤 Hướng dẫn:</strong> Upload tài liệu quy trình ủ rượu (PDF, ảnh, video) 
              lên IPFS để lưu trữ phi tập trung. Hệ thống sẽ trả về CID để truy xuất sau này.
            </p>
          </div>

          {loading ? (
            <div className="text-center py-8">
              <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-wine-600"></div>
              <p className="mt-2 text-gray-600">Đang tải...</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-gray-700 font-semibold mb-2">
                  Chọn vườn nho <span className="text-red-500">*</span>
                </label>
                <select
                  required
                  value={formData.vineyard_id}
                  onChange={(e) => setFormData({ ...formData, vineyard_id: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-wine-500 focus:border-transparent"
                >
                  <option value="">-- Chọn vườn nho --</option>
                  {vineyards.map((vineyard) => (
                    <option key={vineyard.id} value={vineyard.id}>
                      {vineyard.name} ({vineyard.grape_variety})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-gray-700 font-semibold mb-2">
                  Tiêu đề <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-wine-500 focus:border-transparent"
                  placeholder="VD: Quy trình ủ rượu vang đỏ 2024"
                />
              </div>

              <div>
                <label className="block text-gray-700 font-semibold mb-2">
                  Mô tả
                </label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-wine-500 focus:border-transparent"
                  rows="4"
                  placeholder="Mô tả chi tiết về quy trình ủ rượu..."
                ></textarea>
              </div>

              <div>
                <label className="block text-gray-700 font-semibold mb-2">
                  Chọn file <span className="text-red-500">*</span>
                </label>
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-wine-500 transition">
                  <input
                    type="file"
                    required
                    onChange={handleFileChange}
                    className="hidden"
                    id="file-upload"
                    accept=".jpg,.jpeg,.png,.gif,.pdf,.mp4,.avi,.mov,.doc,.docx"
                  />
                  <label
                    htmlFor="file-upload"
                    className="cursor-pointer inline-flex flex-col items-center"
                  >
                    <svg
                      className="w-12 h-12 text-gray-400 mb-2"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"
                      />
                    </svg>
                    <span className="text-wine-600 font-semibold">Click để chọn file</span>
                    <span className="text-sm text-gray-500 mt-1">
                      PDF, Ảnh, Video (tối đa 100MB)
                    </span>
                  </label>
                </div>
                {fileName && (
                  <p className="mt-2 text-sm text-gray-600">
                    <strong>File đã chọn:</strong> {fileName}
                  </p>
                )}
              </div>

              <button
                type="submit"
                disabled={uploading}
                className={`w-full py-3 rounded-lg font-semibold text-white transition ${
                  uploading
                    ? 'bg-gray-400 cursor-not-allowed'
                    : 'bg-wine-600 hover:bg-wine-700'
                }`}
              >
                {uploading ? (
                  <span className="flex items-center justify-center">
                    <svg
                      className="animate-spin h-5 w-5 mr-2"
                      fill="none"
                      viewBox="0 0 24 24"
                    >
                      <circle
                        className="opacity-25"
                        cx="12"
                        cy="12"
                        r="10"
                        stroke="currentColor"
                        strokeWidth="4"
                      ></circle>
                      <path
                        className="opacity-75"
                        fill="currentColor"
                        d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                      ></path>
                    </svg>
                    Đang upload lên IPFS...
                  </span>
                ) : (
                  '📤 Upload lên IPFS'
                )}
              </button>
            </form>
          )}
        </div>

        <div className="mt-6 bg-blue-50 border-l-4 border-blue-500 p-4 rounded">
          <h3 className="font-bold text-blue-900 mb-2">💡 Lưu ý:</h3>
          <ul className="text-sm text-blue-800 space-y-1">
            <li>• File sẽ được lưu trữ trên IPFS (InterPlanetary File System)</li>
            <li>• Sau khi upload, bạn sẽ nhận được CID (Content Identifier)</li>
            <li>• Có thể truy cập file qua: https://ipfs.io/ipfs/YOUR_CID</li>
            <li>• Dữ liệu trên IPFS là bất biến và phi tập trung</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default Upload;

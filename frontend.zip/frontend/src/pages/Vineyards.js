import React, { useState, useEffect } from 'react';
import { vineyardAPI } from '../services/api';
import { toast } from 'react-toastify';

const Vineyards = () => {
  const [vineyards, setVineyards] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [currentVineyard, setCurrentVineyard] = useState({
    id: null,
    name: '',
    latitude: '',
    longitude: '',
    grape_variety: '',
    owner: ''
  });

  useEffect(() => {
    fetchVineyards();
  }, []);

  const fetchVineyards = async () => {
    try {
      setLoading(true);
      const response = await vineyardAPI.getAll();
      setVineyards(response.data.data);
    } catch (error) {
      toast.error('Lỗi khi tải danh sách vườn nho');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editMode) {
        await vineyardAPI.update(currentVineyard.id, currentVineyard);
        toast.success('Cập nhật vườn nho thành công!');
      } else {
        await vineyardAPI.create(currentVineyard);
        toast.success('Thêm vườn nho thành công!');
      }
      setShowModal(false);
      resetForm();
      fetchVineyards();
    } catch (error) {
      toast.error(editMode ? 'Lỗi khi cập nhật vườn nho' : 'Lỗi khi thêm vườn nho');
    }
  };

  const handleEdit = (vineyard) => {
    setCurrentVineyard(vineyard);
    setEditMode(true);
    setShowModal(true);
  };

  const handleDelete = async (id) => {
    if (window.confirm('Bạn có chắc chắn muốn xóa vườn nho này?')) {
      try {
        await vineyardAPI.delete(id);
        toast.success('Xóa vườn nho thành công!');
        fetchVineyards();
      } catch (error) {
        toast.error('Lỗi khi xóa vườn nho');
      }
    }
  };

  const resetForm = () => {
    setCurrentVineyard({
      id: null,
      name: '',
      latitude: '',
      longitude: '',
      grape_variety: '',
      owner: ''
    });
    setEditMode(false);
  };

  const openAddModal = () => {
    resetForm();
    setShowModal(true);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-wine-800">Quản lý vườn nho</h1>
        <button
          onClick={openAddModal}
          className="bg-wine-600 text-white px-6 py-2 rounded-lg hover:bg-wine-700 transition"
        >
          + Thêm vườn nho
        </button>
      </div>

      {loading ? (
        <div className="text-center py-12">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-wine-600"></div>
          <p className="mt-4 text-gray-600">Đang tải...</p>
        </div>
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {vineyards.map((vineyard) => (
            <div key={vineyard.id} className="bg-white rounded-lg shadow-lg p-6 hover:shadow-xl transition">
              <h3 className="text-xl font-bold text-wine-700 mb-3">{vineyard.name}</h3>
              <div className="space-y-2 mb-4 text-gray-600">
                <p><strong>Giống nho:</strong> {vineyard.grape_variety}</p>
                <p><strong>Chủ sở hữu:</strong> {vineyard.owner}</p>
                <p><strong>Tọa độ:</strong> {vineyard.latitude}, {vineyard.longitude}</p>
                <p className="text-sm text-gray-500">
                  <a
                    href={`https://www.google.com/maps?q=${vineyard.latitude},${vineyard.longitude}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-wine-600 hover:underline"
                  >
                    📍 Xem trên bản đồ
                  </a>
                </p>
              </div>
              <div className="flex space-x-2">
                <button
                  onClick={() => handleEdit(vineyard)}
                  className="flex-1 bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition"
                >
                  Sửa
                </button>
                <button
                  onClick={() => handleDelete(vineyard.id)}
                  className="flex-1 bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600 transition"
                >
                  Xóa
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {vineyards.length === 0 && !loading && (
        <div className="text-center py-12 bg-white rounded-lg shadow">
          <p className="text-gray-500 text-lg">Chưa có vườn nho nào. Hãy thêm vườn nho đầu tiên!</p>
        </div>
      )}

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-8 max-w-md w-full mx-4">
            <h2 className="text-2xl font-bold text-wine-800 mb-4">
              {editMode ? 'Sửa vườn nho' : 'Thêm vườn nho mới'}
            </h2>
            <form onSubmit={handleSubmit}>
              <div className="space-y-4">
                <div>
                  <label className="block text-gray-700 font-semibold mb-2">Tên vườn nho</label>
                  <input
                    type="text"
                    required
                    value={currentVineyard.name}
                    onChange={(e) => setCurrentVineyard({ ...currentVineyard, name: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-wine-500 focus:border-transparent"
                    placeholder="VD: Vườn nho Đà Lạt Premium"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-gray-700 font-semibold mb-2">Vĩ độ</label>
                    <input
                      type="number"
                      step="any"
                      required
                      value={currentVineyard.latitude}
                      onChange={(e) => setCurrentVineyard({ ...currentVineyard, latitude: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-wine-500 focus:border-transparent"
                      placeholder="11.9404"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-700 font-semibold mb-2">Kinh độ</label>
                    <input
                      type="number"
                      step="any"
                      required
                      value={currentVineyard.longitude}
                      onChange={(e) => setCurrentVineyard({ ...currentVineyard, longitude: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-wine-500 focus:border-transparent"
                      placeholder="108.4583"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-gray-700 font-semibold mb-2">Giống nho</label>
                  <input
                    type="text"
                    required
                    value={currentVineyard.grape_variety}
                    onChange={(e) => setCurrentVineyard({ ...currentVineyard, grape_variety: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-wine-500 focus:border-transparent"
                    placeholder="VD: Cabernet Sauvignon"
                  />
                </div>
                <div>
                  <label className="block text-gray-700 font-semibold mb-2">Chủ sở hữu</label>
                  <input
                    type="text"
                    required
                    value={currentVineyard.owner}
                    onChange={(e) => setCurrentVineyard({ ...currentVineyard, owner: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-wine-500 focus:border-transparent"
                    placeholder="VD: Công ty TNHH Rượu Vang Đà Lạt"
                  />
                </div>
              </div>
              <div className="flex space-x-4 mt-6">
                <button
                  type="button"
                  onClick={() => {
                    setShowModal(false);
                    resetForm();
                  }}
                  className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-100 transition"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-wine-600 text-white px-4 py-2 rounded-lg hover:bg-wine-700 transition"
                >
                  {editMode ? 'Cập nhật' : 'Thêm mới'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Vineyards;

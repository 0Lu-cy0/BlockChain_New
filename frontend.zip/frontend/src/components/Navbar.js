import React from 'react';
import { Link, useLocation } from 'react-router-dom';

const Navbar = () => {
  const location = useLocation();

  const isActive = (path) => {
    return location.pathname === path ? 'bg-wine-700' : '';
  };

  return (
    <nav className="bg-wine-600 text-white shadow-lg">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center py-4">
          <Link to="/" className="text-2xl font-bold flex items-center">
            <span className="mr-2">🍷</span>
            Truy Xuất Rượu Vang Cao Cấp
          </Link>
          <div className="flex space-x-1">
            <Link
              to="/"
              className={`px-4 py-2 rounded-md hover:bg-wine-700 transition ${isActive('/')}`}
            >
              Trang chủ
            </Link>
            <Link
              to="/vineyards"
              className={`px-4 py-2 rounded-md hover:bg-wine-700 transition ${isActive('/vineyards')}`}
            >
              Quản lý vườn nho
            </Link>
            <Link
              to="/upload"
              className={`px-4 py-2 rounded-md hover:bg-wine-700 transition ${isActive('/upload')}`}
            >
              Upload quy trình
            </Link>
            <Link
              to="/traceability"
              className={`px-4 py-2 rounded-md hover:bg-wine-700 transition ${isActive('/traceability')}`}
            >
              Truy xuất nguồn gốc
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
